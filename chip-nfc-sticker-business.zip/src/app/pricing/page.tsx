import { redirect } from "next/navigation";

export default function PricingPage() {
  redirect("/pilot-program");
}
