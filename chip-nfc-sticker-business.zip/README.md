# MerQato — Connected Business Experiences
**Official Website:** [merqato.digital](https://merqato.digital)  
**Developed by:** Palawan Collective (Puerto Princesa, Palawan, Philippines)  
**Primary Market:** Hospitality businesses in Palawan (El Nido, Coron, San Vicente, Puerto Princesa)  
**Expansion Markets:** Tourism, property management, service businesses, equipment rental, solar energy, marine operations, manufacturing, and logistics.

---

## 1. Executive Summary & Business Positioning

MerQato is a connected-business technology platform that turns everyday objects (dining tables, resort room keycards, boat helms, solar inverters, and craft products) into powerful digital touchpoints using **tactile Near Field Communication (NFC)** hardware, precision QR encoding, and high-performance edge web applications.

- **Main Headline:** Make Every Tap Count.
- **Supporting Headline:** Turn everyday objects into powerful business tools.
- **Physical Touch to Instant Action:** Sub-600ms load time. Zero mobile app download required.

---

## 2. Visual Direction & Design System

- Warm off-white backgrounds (`#FAF9F5`), charcoal typography (`#141518`), and subtle terracotta clay accents (`#B85D32`).
- Restrained color system without purple SaaS gradients or generic stock illustrations.
- Industrial hardware presentation featuring solid Palawan teak tabletop discs, brushed space-charcoal aluminum standups, and IP68 sealed waterproof asset labels.
- Mobile-first responsive layout with zero image cutoffs, animated concentric NFC ripple wave indicators, and live HUD badges.
- Native Light and Dark mode toggle with persistent local storage state.

---

## 3. Architecture & Tech Stack

- **Framework:** Next.js (App Router) with TypeScript
- **Styling:** Tailwind CSS with custom editorial typography
- **Icons:** Lucide React
- **Database:** PostgreSQL with Drizzle ORM
- **Authentication:** Role-based HTTP-only signed session tokens (Owner, Admin, Editor, Viewer)
- **Deployment:** Docker & Coolify ready (self-hosted VPS friendly)

---

## 4. Default Administrator Credentials

On initial database bootstrap, the following accounts are initialized:

| Role | Email | Password |
|---|---|---|
| **Owner** | `admin@merqato.digital` | `Merqato2026!Admin` |
| **Editor** | `editor@merqato.digital` | `Merqato2026!Editor` |

Admin Portal URL: `/admin`  
Direct Login URL: `/admin/login`

---

## 5. Full Backend Admin CMS Capabilities

1. **Dashboard (`/admin`):** Live CRM pipeline stats, hardware catalog counts, dynamic sectors, and recent audit activity.
2. **Lead Pipeline CRM (`/admin/leads`):** Search, status transitions (`new`, `contacted`, `qualified`, `pilot_offer`, `closed`, `archived`), internal staff note threads, and CSV export.
3. **Industry Sectors (`/admin/industries`):** Add, edit, archive, and delete unlimited industries and operational benefits without code changes.
4. **Digital Use Cases (`/admin/use-cases`):** Configure interactive software modules, simulator modes, and multi-industry assignments.
5. **Physical Hardware (`/admin/products`):** Full catalog management for smart stickers, teak standups, NFC cards, marine wristbands, and solar labels. Includes variant matrices and spec sheet links.
6. **Page Content (`/admin/pages`):** Manage hero headlines, subheadlines, descriptions, and SEO meta tags.
7. **Site & Pilot Settings (`/admin/settings`):** Configure the 90-day pilot program offer (₱1,000 setup commitment, duration, spots left, inclusions), contact email/phone, and address.
8. **Media Library (`/admin/media`):** Preview, copy URLs, and manage hardware product photography.
9. **Audit Logs (`/admin/audit-logs`):** Immutable server-side logging of all operations.
10. **Team & Permissions (`/admin/team`):** Enforce Owner, Admin, Editor, and Viewer role security.
11. **Platform Roadmap (`/admin/platform-roadmap`):** Documents clean integration boundaries for future NFC/QR telemetry clusters.

---

## 6. Self-Hosted Deployment (Docker & Coolify)

### Using Docker Compose:
```bash
docker compose up -d --build
```

### Coolify Setup:
1. Connect your Git repository or Dockerfile.
2. Select **Dockerfile** as the build pack.
3. Add the environment variables:
   - `DATABASE_URL`: `postgresql://postgres:postgres@db:5432/app_db`
   - `ADMIN_SESSION_SECRET`: (A 32+ character random string)
   - `NODE_ENV`: `production`
4. Expose port `3000` to your domain `merqato.digital`.

---

## 7. Pilot Program Terms

- **Duration:** 90 days
- **Setup Commitment:** ₱1,000 one-time
- **Inclusions:** 25 custom-designed physical MerQato smart NFC & QR tabletop discs or standups, full digital guest portal hosting, 1-tap Google Review accelerator, on-site setup in Palawan, and hardware ownership retention.
